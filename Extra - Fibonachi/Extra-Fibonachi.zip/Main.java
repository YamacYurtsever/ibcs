import java.util.Scanner;

class Main
{
  public static void main(String[] args)
  {
    Scanner sc = new Scanner(System.in);
    int num1 = 0;
    int num2 = 1;
    int fibNum = 0;

    System.out.println("Enter a number: ");
    int enteredNum = sc.nextInt();

    while (true)
    {
      fibNum = num1  + num2;
      num1 = num2;
      num2 = fibNum;
      if (fibNum > enteredNum)
      {
        break;
      }
      System.out.println(fibNum);
    }
    System.out.println("These are the fibonachi numbers smaller than the number you entered");
  }
}