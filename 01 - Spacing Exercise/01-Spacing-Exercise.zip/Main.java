class Main
{

  public static void main(String[] args)
  {

    System.out.println("          SIMPLE MATH          ");
    System.out.println("-------------------------------");
    System.out.println(5 + " + " + 10 + " = " + (5 + 10));
    System.out.println(30 + " / " + 5 + " = " + (30 / 5));
    System.out.println(50 + " + " + 20 + " - " + 6 + " * " + 3 + " = " + (50 + 20 - 6 * 3));
    System.out.println(40 + " / " + "(" + 3 + " + " + 5 + ")" + " * " + 2 + " = " + (40 / (3 + 5) * 2)) ;
    System.out.println("\nThe remainder when you divide " + 15 + " by " + 4 + " is " + (15 / 4) + ".");
    System.out.println("\nJack had " + 3 + " pencils and Jill had " + 5 + ".");
    System.out.println("Jack and Jill had " + (5 + 3) + " pencils.");

  }

}