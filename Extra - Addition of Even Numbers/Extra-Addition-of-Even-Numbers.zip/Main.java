import java.util.Scanner;

class Main
{
  public static void main(String[] args)
	{
    Scanner sc = new Scanner (System.in);
		System.out.println("Enter the amount of integers you want to add");
		int evenNum = sc.nextInt();

		System.out.println(AdditionMaker(evenNum));
  }

	private static int AdditionMaker(int evenNum)
	{
		int addition = 0;

		for (int i = 1; i <= evenNum; i++)
		{
			System.out.print(2 * i + " ");
			addition += (2 * i);
		}
		System.out.println("");
		
		return addition;
	}
}