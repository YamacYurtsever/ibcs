import java.util.Scanner;

class Main
{
  public static void main(String[] args)
  {
    Scanner input = new Scanner(System.in);
    int value;
    char grade;
    char symbol = ' ';

    System.out.println("Enter a numerical value--> ");
    value = input.nextInt();

    if (value >= 90)
    {
      grade = 'A';

      if (value <= 93)
        symbol = '-';

      else if (value >= 97)
        symbol = '+';
    }

    else if (value >= 80)
    {
      grade = 'B';

      if (value <= 83)
        symbol = '-';

      else if (value >= 87)
        symbol = '+';
    }

    else if (value >= 70)
    {
      grade = 'C';

      if (value <= 73)
        symbol = '-';

      else if (value >= 77)
        symbol = '+';
    }

    else
      grade = 'F';

    System.out.println("Letter Grade = " + grade + symbol);
  }
}