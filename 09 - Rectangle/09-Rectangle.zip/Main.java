import java.util.Scanner;

class Main
{
  public static void main(String[] args)
  {
    int length;
    int width;
    int perimeter;
    int area;

    Scanner input = new Scanner(System.in);

    System.out.println("Enter the length --> ");
    length = input.nextInt();
    System.out.println("Enter the width --> ");
    width = input.nextInt();

    perimeter = 2 * length + 2 * width;
    area = length * width;
    
    System.out.println("Perimeter = " + perimeter);
    System.out.println("Area = " + area);
  }
}