import java.util.Scanner;

class Main
{
  public static void main(String[] args)
  {
    int a = 0;
    while (a <= 25)
    {
      System.out.print(a + " ");
      a++;
    }

    System.out.println("\n");

    int b = 10;
    while (b > 0)
    {
      System.out.print(b + " ");
      b--;
    }

    System.out.println("\n");

    int c = 1;
    while (c <= 40)
    {
      System.out.print(c + " ");
      c += 2;
    }

    System.out.println("\n");

    int d = 2;
    while (d <= 40)
    {
      System.out.print(d + " ");
      d += 2;
    }

    System.out.println("\n");

    int e = 0;
    while (e <= 200)
    {
      System.out.print(e + " ");
      e += 10;
    }

    System.out.println("\n");

    int f = -10;
    while (f >= -20)
    {
      System.out.print(f + " ");
      f--;
    }

    System.out.println("\n");

    int g = 0;
    while (g < 10)
    {
      System.out.println("computer");
      g++;
    }

    System.out.println("");

    Scanner sc = new Scanner(System.in);
    System.out.println("how many times would you like to see the same sentence?");
    int x = sc.nextInt();
    int h = 0;
    while (h < x)
    {
      System.out.println("This will be printed " + x + " times to the screen");
      h++;
    }
  }
}