import java.util.Scanner;

class Main
{
  public static void main(String[] args)
  {
    Scanner input = new Scanner(System.in);
    String type;
    String letter = " ";

    System.out.println("Enter Side 1 --> ");
    int side1 = input.nextInt();

    System.out.println("Enter Side 2 --> ");
    int side2 = input.nextInt();

    System.out.println("Enter Side 3 --> ");
    int side3 = input.nextInt();

    if (side1 == side2 && side2 == side3)
    {
      type = "equilateral";
      letter = "n ";
    }
    else if (side1 != side2 && side2 != side3 && side1 != side3)
    {
      type = "scalene";
    }
    else
    {
      type = "isosceles";
      letter = "n ";
    }

    System.out.println("\nThis triangle is a" + letter + type);
  }
}