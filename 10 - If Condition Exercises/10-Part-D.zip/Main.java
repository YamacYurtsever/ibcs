import java.util.Scanner;

class Main
{
  public static void main(String[] args)
  {
    int number1;
    int number2;

    Scanner input = new Scanner(System.in);

    System.out.println("Input the first number: ");
    number1 = input.nextInt();

    System.out.println("Input the second number: ");
    number2 = input.nextInt();

    if (number1 > number2)
      System.out.println("The greatest: " + number1);

    else if (number1 == number2)
      System.out.println("They are equal");

    else
      System.out.println("The greatest: " + number2);
  }
}