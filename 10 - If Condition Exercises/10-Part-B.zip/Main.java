import java.util.Scanner;

class Main
{
  public static void main(String[] args)
  {
    int number;

    Scanner input = new Scanner(System.in);

    System.out.println("Input a number: ");
    number = input.nextInt();

    if (number % 2 == 0)
      System.out.println(number + " is an even number");

    else
      System.out.println(number + " is not an even number");
  }
}