import java.util.Scanner;

class Main
{
  public static void main(String[] args)
  {
    Scanner sc = new Scanner(System.in);
    String name;
    String secondName;
    String surname;
    char lastSurname;
    int year;
    String lastYear;

    /*System.out.println("Enter your name: ");
    name = sc.nextLine();

    System.out.println("Enter your surname: ");
    surname = sc.nextLine();
    lastSurname = surname.charAt(0);

    System.out.println("Enter your graduation year: ");
    year = sc.nextInt();
    year %= 100;
    lastYear = Integer.toString(year);

    System.out.println(name + lastSurname + lastYear + "@stu.uaa.k12.tr");*/

    System.out.println("Are you a: \n1. Student \n2. Teacher");
    int status = sc.nextInt();
    sc.nextLine();

    if (status == 1)
    {
      System.out.println("Enter your name: ");
      name = sc.nextLine();

      System.out.println("Enter your second name: ");
      secondName = sc.nextLine();

      System.out.println("Enter your surname: ");
      surname = sc.nextLine();
      lastSurname = surname.charAt(0);

      System.out.println("Enter your graduation year: ");
      year = sc.nextInt();
      year %= 100;
      lastYear = Integer.toString(year);

      System.out.println(name + secondName + lastSurname + lastYear + "@stu.uaa.k12.tr");
    }
    else if (status == 2)
    {
      System.out.println("Enter your name: ");
      name = sc.nextLine();

      System.out.println("Enter your surname: ");
      surname = sc.nextLine();
      lastSurname = surname.charAt(0);

      System.out.println(name + lastSurname + "@stu.uaa.k12.tr");
    }
    else
    {
      System.out.println("Wrong input");
    }
  }
}