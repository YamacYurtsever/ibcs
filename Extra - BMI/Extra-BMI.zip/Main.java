import java.util.Scanner;

class Main
{
  public static void main(String[] args)
	{
    Scanner sc = new Scanner(System.in);
		System.out.println("Enter height (in m): ");
		double height = sc.nextDouble();
		System.out.println("Enter weight (in kg): ");
		double weight = sc.nextDouble();

		double bmi = CalculateBMI(height, weight);
		String bodyType = DetermineBodyType(bmi);

		System.out.println("Your body type is: " + bodyType);
  }

	private static double CalculateBMI (double height, double weight)
	{
		double bmi = (weight / (height * height));
		return bmi;
	}

	private static String DetermineBodyType(double bmi)
	{
		String bodyType;
		if (bmi >= 30)
			bodyType = "obese";
		else if (bmi >= 25)
			bodyType = "overweight";
		else if (bmi >= 18.5)
			bodyType = "normal";
		else
			bodyType = "underweight";
		return bodyType;
	}
}