import java.util.Scanner;

class Main
{
  public static void main(String[] args)
  {
    //variables
    Scanner sc = new Scanner(System.in);
    int playerNum = 1;
    int stoneNum = 20;
    int removedStone;

    while (stoneNum > 0)
    {
       //get the number of reduced stones from the user
      System.out.println("There are " + stoneNum + " stones left");
      System.out.println("Player " + playerNum + " would you like  to remove 1 or 2 stones? ");
      removedStone = sc.nextInt();

       //check if the input is wrong
      while (removedStone != 1 && removedStone != 2)
      {
        System.out.println("Please enter 1 or 2: ");
        removedStone = sc.nextInt();
      }

      //reduce the stones
      stoneNum -= removedStone;

      //change the user
      if (playerNum == 1)
        playerNum = 2;
      else if (playerNum == 2)
        playerNum = 1;
      System.out.println("");
    }
    //print the result
    System.out.println("Player " + playerNum + " wins!");
  }
}