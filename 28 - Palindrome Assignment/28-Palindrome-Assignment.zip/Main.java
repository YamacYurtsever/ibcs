import java.util.Scanner;

import javax.lang.model.util.ElementScanner6;

class Main
{
  public static void main(String[] args)
  {
    Scanner sc = new Scanner(System.in);
    int x = 0;
    String word;
    boolean palindrome = true;
    String cont = "Y";

    while (cont.equals("Y"))
    {
      System.out.println("Word --> ");
      word = sc.nextLine();

      for (x = 0; x < (word.length() - (1 + x)); x++)
      {
        if (word.charAt(x) == word.charAt((word.length() - 1) - x))
        {
          palindrome = true;
        }
        else
        {
          palindrome = false;
          break;
        }
      }

      if (palindrome)
        System.out.println(word + " is a palindrome.");
      else
        System.out.println(word + " is not a palindrome.");

      System.out.println(" \ncontinue[Y/N]?");
      cont = sc.nextLine();
      System.out.println();
    }
  }
}