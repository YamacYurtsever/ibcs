import java.util.Scanner;

class Main
{
  public static void main(String[] args)
  {
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter a number: ");
    int num = sc.nextInt();
    int steps = 0;

    while (num > 1)
    {
      if (num % 2 == 0)
      {
        System.out.print(num + " is even, so I take half: ");
        num /= 2;
        System.out.println(num);
      }
      else
      {
        System.out.print(num + " is odd, so I make 3n+1: ");
        num *= 3;
        num++;
        System.out.println(num);
      }
      steps++;
    }
    System.out.println("The process took " + steps + " to reach 1");
  }
}