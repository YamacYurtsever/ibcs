class Main
{
  public static void main(String[] args)
  {
    String name = "Büşra";
    int age = 32;
    String city = "Istanbul";
    char gender = 'F';

    System.out.println("Hello " + name + "!");
    System.out.println("Your age is " + age + ".");
    System.out.println("Your city is " + city + ".");
    System.out.println("Your gender is " + gender + ".");
  }
}