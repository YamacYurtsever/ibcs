import java.util.ArrayList;

class Main
{
  public static void main(String[] args)
  {
    /*ArrayList<Long> numbers = new ArrayList<Long>();

    for (int i = 1; i <= 1000; i++)
    {
      long random = (long)(Math.random() * 8999999999L + 1000000000L);

      while (numbers.contains(random))
      {
        random = (long)(Math.random() * 8999999999L + 1000000000L);
      }
        numbers.add(random);
    }

    for (Long num : numbers)
    {
      System.out.println(num);
    }*/

    for (int i = 0; i < 1000; i++)
    {
      int firstPart = 10000 + i;
      int secondPart = (int)(Math.random() * 89999 + 10000);
      System.out.println(firstPart + "" + secondPart);
    }
  }
}