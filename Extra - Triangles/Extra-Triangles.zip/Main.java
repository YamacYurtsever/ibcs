import java.util.Scanner;

class Main
{
  public static void main(String[] args)
  {
    Scanner sc = new Scanner(System.in);

    while (true)
    {
      //Input Type
      System.out.println("What type of a triangle do you want?\n1. Triangle\n2. Right Triangle");
      int type = sc.nextInt();

      //Input Direction
      if (type == 1)
      {
        System.out.println("Where do you want it to look?\n1. Up\n2. Down\n3. Right\n4. Left");
      }
      else if (type == 2)
      {
        System.out.println("Where do you want it to look?\n1. Up Right\n2. Up Left\n3. Down Right\n4. Down Left");
      }
      else
      {
        System.out.println("Wrong input");
      }
      int direction = sc.nextInt();
      
      //Input Length
      System.out.println("How long do you want the triangle to be?");
      int length = sc.nextInt();

      //Normal Triangle
      if(type == 1)
      {
        //Looking Up
        if (direction == 1)
        {
          int spaceBeforeNum = length - 1;
          int starNum = 1;
          for (int column = 0; column < length; column++)
          {
            for(int space = 0; space < spaceBeforeNum; space++)
            {
              System.out.print(" ");
            }
            for(int star = 0; star < starNum; star++)
            {
              System.out.print("*");
            }
            spaceBeforeNum--;
            starNum += 2;
            System.out.println("");
          }
        }
        //Looking Down
        else if (direction == 2)
        {
          int spaceBeforeNum = 0;
          int starNum = (length * 2) - 1;
          for (int column = 0; column < length; column++)
          {
            for(int space = 0; space < spaceBeforeNum; space++)
            {
              System.out.print(" ");
            }
            for(int star = 0; star < starNum; star++)
            {
              System.out.print("*");
            }
            spaceBeforeNum++;
            starNum -= 2;
            System.out.println("");
          }
        }
        //Looking Right
        else if (direction == 3)
        {
          int starNum = 1;
          boolean starNumIncreasing = true;
          for (int column = 0; column < (length * 2) - 1; column++)
          {
            for(int star = 0; star < starNum; star++)
            {
              System.out.print("*");
            }
            if (starNum == length)
              starNumIncreasing = false;
            if (starNumIncreasing)
              starNum++;
            else
              starNum--;
            System.out.println("");
          }
        }
        //Looking Left
        else if (direction == 4)
        {
          int spaceBeforeNum = length - 1;
          int starNum = 1;
          boolean starNumIncreasing = true;
          for (int column = 0; column < (length * 2) - 1; column++)
          {
            for(int space = 0; space < spaceBeforeNum; space++)
            {
              System.out.print(" ");
            }
            for(int star = 0; star < starNum; star++)
            {
              System.out.print("*");
            }
            if (starNum == length)
              starNumIncreasing = false;
            if (starNumIncreasing)
            {
              spaceBeforeNum--;
              starNum++;
            }
            else
            {
              spaceBeforeNum++;
              starNum--;
            }
            System.out.println("");
          }
        }
        else
        {
          System.out.println("Wrong input");
        }
      }
      //Right Triangle
      else if(type == 2)
      {
        //Looking Up Right
        if (direction == 1)
        {
          int spaceBeforeNum = length - 1;
          int starNum = 1;
          for (int column = 0; column < length; column++)
          {
            for(int space = 0; space < spaceBeforeNum; space++)
            {
              System.out.print(" ");
            }
            for(int star = 0; star < starNum; star++)
            {
              System.out.print("*");
            }
            spaceBeforeNum--;
            starNum++;
            System.out.println("");
          }
        }
        //Looking Up Left
        else if (direction == 2)
        {
          int starNum = 1;
          for (int column = 0; column < length; column++)
          {
            for(int star = 0; star < starNum; star++)
            {
              System.out.print("*");
            }
            starNum++;
            System.out.println("");
          }
        }
        //Looking Down Right
        else if (direction == 3)
        {
          int spaceBeforeNum = 0;  
          int starNum = length;
          for (int column = 0; column < length; column++)
          {
            for(int space = 0; space < spaceBeforeNum; space++)
            {
              System.out.print(" ");
            }
            for(int star = 0; star < starNum; star++)
            {
              System.out.print("*");
            }
            spaceBeforeNum++;
            starNum--;
            System.out.println("");
          }
        }
        //Looking Down Left
        else if (direction == 4)
        {
          int starNum = length;
          for (int column = 0; column < length; column++)
          {
            for(int star = 0; star < starNum; star++)
            {
              System.out.print("*");
            }
            starNum--;
            System.out.println("");
          }
        }
        else
        {
          System.out.println("Wrong input");
        }
      }
      else
      {
        System.out.println("Wrong input");
      }
    }
  }
}