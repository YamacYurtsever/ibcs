import java.util.Scanner;
class Main
{
  public static void main(String[] args)
	{
    int[][] array = new int[3][5];
		int[][] otherArray = new int[3][15];

		//Input Numbers
    Scanner sc = new Scanner(System.in);
		for (int row = 0; row < array.length; row++)
		{
			System.out.println("\nRow " + (row+1) + "\nEnter " + array[row].length + " numbers:");
			for (int column = 0; column < array[row].length; column++)
			{
				array[row][column] = sc.nextInt();
			}
		}
		System.out.println("");

		//Order Numbers 
		int index20 = 0;
		int index10 = 0;
		int index0 = 0;
    for(int a = 0; a < array.length; a++)
		{
      for (int b = 0; b < array[a].length; b++) 
			{
				if(array[a][b] > 20)
				{
					otherArray[0][index20] = array[a][b];
					index20++;
				}
				else if(array[a][b] > 10)
				{
					otherArray[1][index10] = array[a][b];
					index10++;
				}
				else
				{
					otherArray[2][index0] = array[a][b];
					index0++;
				}
     }
   }

		//Print Numbers
		for(int f = 0; f < otherArray.length; f++)
		{
			if (f == 0)
			{
				for (int r = 0; r < index20; r++) 
				{
					System.out.print(otherArray[f][r] + " ");
				}
				System.out.println("");
			}
			else if (f == 1)
			{
				for (int t = 0; t < index10; t++) 
				{
					System.out.print(otherArray[f][t] + " ");
				}
				System.out.println("");
			}
			else
			{
				for (int y = 0; y < index0; y++) 
				{
					System.out.print(otherArray[f][y] + " ");
				}
				System.out.println("");
			}
		}
  }
}