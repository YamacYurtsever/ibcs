class Main
{
  public static void main(String[] args)
	{
		int[][] array = {{255, 184, 178, 84, 129}, {84, 255, 255, 130, 84}, {78, 255, 0, 0, 78}, {84, 130, 255, 130, 84}};

		System.out.println(countWhitePixels(array));
		
		processImage(array);
		for (int[] arr : array)
		{
			for (int num : arr)
			{
				System.out.print(num + " ");
			}
			System.out.println();
		}
  }

	private static int countWhitePixels(int[][] array)
	{
		int white = 0;
		for (int[] arr : array)
		{
			for (int num : arr)
			{
				if (num == 255)
					white++;
			}
		}
		return white;
	}

	private static int[][] processImage(int[][] array)
	{
		for (int a = 0; a < array.length - 3; a++)
		{
			for (int b = 0; b < array[0].length - 3; b++)
			{
				array[a][b] -= array[a + 2][b + 2];
				if (array[a][b] < 0)
					array[a][b] = 0;
			}
		}
		return array;
	}
}