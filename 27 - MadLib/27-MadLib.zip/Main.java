import java.util.Scanner;

class Main
{
  public static void main(String[] args)
  {
    Scanner sc = new Scanner(System.in);

    System.out.println("Enter a noun: ");
    String word1 = sc.nextLine();
    System.out.println("Enter a vehicle: ");
    String word2 = sc.nextLine();
    System.out.println("Enter an adjective: ");
    String word3 = sc.nextLine();
    System.out.println("Enter a characteristic: ");
    String word4 = sc.nextLine();
    System.out.println("Enter a group of people: ");
    String word5 = sc.nextLine();
    System.out.println("Enter an activity: ");
    String word6 = sc.nextLine();
    System.out.println("Enter a weather condition: ");
    String word7 = sc.nextLine();
    System.out.println("Enter a condition of an object: ");
    String word8 = sc.nextLine();
    System.out.println("Enter a noun form of an adjective: ");
    String word9 = sc.nextLine();
    System.out.println("Enter an achievement: ");
    String word10 = sc.nextLine();
    System.out.println("Enter a family member: ");
    String word11 = sc.nextLine();
    System.out.println("Enter a family occupation: ");
    String word12 = sc.nextLine();

    String song = ("Just sit right back and you`ll hear a tale,\nA tale of a fateful [1] ,\nThat started from this tropic port,\nAboard this tiny [2] .\nThe mate was a [3] sailor man,\nThe skipper [4] and sure.\nFive [5] set sail that day,\nFor a three hour [6] , a three hour [6] .\nThe weather started getting [7] ,\nThe tiny [2] was [8] ,\nIf not for the [9] of the fearless crew ,\nThe [10] would be lost, the [10] would be lost.\nThe [2] set ground on the shore of this uncharted desert isle,\nWith Gilligan, The Skipper too,\nThe millionaire and his [11] , The movie [12] ,\nAnd The Rest, Here on Gilligan`s Isle.");

    song = song.replace("[1]", word1);
    song = song.replace("[2]", word2);
    song = song.replace("[3]", word3);
    song = song.replace("[4]", word4);
    song = song.replace("[5]", word5);
    song = song.replace("[6]", word6);
    song = song.replace("[7]", word7);
    song = song.replace("[8]", word8);
    song = song.replace("[9]", word9);
    song = song.replace("[10]", word10);
    song = song.replace("[11]", word11);
    song = song.replace("[12]", word12);

    System.out.println(song);
  }
}