class Main
{
  public static void main(String[] args)
  {
    int a = 0;
    do
    {
      System.out.print(a + " ");
      a++;
    }
    while(a < 20);

    System.out.println("");

    int b = 1;
    do
    {
      if (b % 2 != 0)
      {
        System.out.print(b + " ");
      }
      b++;
    }
    while(b < 50);

    System.out.println("");

    int c = 0;
    do
    {
      System.out.print(c + " ");
      c += 10;
    }
    while(c < 200);

    System.out.println("");

    int d = 0;
    do
    {
      System.out.print((char)d);
      d++;
    }
    while(d < 128);
  }
}