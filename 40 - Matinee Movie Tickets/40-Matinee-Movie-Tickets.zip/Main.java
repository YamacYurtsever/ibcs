import java.util.Scanner;

class Main
{
  public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
    
		double price = CalculatePrice(GetAge(sc), GetTime(sc));
		if (price == 0.00)
			System.out.println("You can not buy a ticket right now");
		else
			System.out.println("The price is: $" + price);
  }

	private static int GetAge(Scanner sc)
	{
		System.out.println("Enter your age: ");
		int age = sc.nextInt();
		return age;
	}

	private static int GetTime(Scanner sc)
	{
		System.out.println("Enter the time: ");
		int time = sc.nextInt();
		return time;
	}

	private static double CalculatePrice(int age, int time)
	{
		double price = 0.00;

		if (time >= 2200)
		{
			if (age > 13)
				price = 4.00;
		}
		else if (time >= 1700)
		{
			if (age > 13)
				price = 8.00;
			else
				price = 4.00;
		}
		else
		{
			if (age > 13)
				price = 6.00;
			else
				price = 2.00;
		}

		return price;
	}
}