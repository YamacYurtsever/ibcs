import java.util.*;

class Main
{
	private static Scanner keyboard = new Scanner(System.in);
	public static void main(String[] args)
	{
		System.out.println("******************");
		System.out.println(" Test Method1");
		System.out.println("******************");
		System.out.println("Weight is " + method1(150));
		System.out.println("Weight is " + method1(99));
		System.out.println("Weight is " + method1(200));
		System.out.println("Weight is " + method1(300));
		System.out.println("\n\n******************");
		System.out.println(" Test Method2");
		System.out.println("******************");
		method2("Computers are fun!");
		System.out.println("\n\n******************");
		System.out.println(" Test Method3");
		System.out.println("******************");
		System.out.println("\nCount = " + method3());
		System.out.println("\n\n******************");
		System.out.println(" Test Method4");
		System.out.println("******************");
		System.out.println("String = " + method4("red"));
		System.out.println("String = " + method4("green"));
		System.out.println("String = " + method4("blue"));
		System.out.println("\n\n******************");
		System.out.println(" Test Method5");
		System.out.println("******************");
		System.out.println("Random Number = " + method5(5));
		System.out.println("Random Number = " + method5(50));
		System.out.println("Random Number = " + method5(500));
		System.out.println();
	}

	/** This method returns a string using the following
	* conditions: if weight is less than 100 it returns
	* "small", if weight is greater than or equal to 100
	* and less than or equal to 200 it returns "medium",
	* if weight is greater than 200 it returns "large".
	* @return the string "small", "medium", or "large"
	* @param weight number representing a weight
	*/

	public static String method1(int weight)
	{
		String size;

		if (weight < 100)
			size = "Small";
		else if (weight <= 200)
			size = "Medium";
		else
			size = "Large";

		return size;
	}

	/** This method prints phrase 10 times.
	* @ param phrase the string to be printed
	*/

	public static void method2(String phrase)
	{
		for (int i = 0; i < 10; i++)
		{
			System.out.println(phrase);
		}
	}

	/** This method allows a user to enter an unknown
	* number of integers from the keyboard. When the
	* sentinel value -1 is entered the method returns
	* the count of the number of integers entered.
	* @return count of the number of integers entered
	*/

	public static int method3()
	{
		int num = 0;
		int count = -1;
		while (num != -1)
		{
			System.out.print("Enter a number:");
			num = keyboard.nextInt();
			count++;
		}
		return count;
	}

	/** This method returns a string containing the
	* first and last letter of str concatenated
	* together.
	* @return a string containing two letters
	* @param str the string from which to extract
	* the first and last letters
	*/

	public static String method4(String str)
	{
		char firstChar = str.charAt(0);
		char lastChar = str.charAt(str.length() - 1);
		String merged = "" + firstChar + lastChar;
		return merged;
	}

	/** This method returns a random number.
	* @return a random number in range of 0 to upper-1
	* @param upper the upper limit of the random number
	*/

	public static int method5(int upper)
	{
		int randomNum = (int) (Math.random() * (upper - 1));
		return randomNum;
	}
}