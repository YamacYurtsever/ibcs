import java.util.Scanner;

class Main
{
  public static void main(String[] args)
  {
    int[] A = new int[5];
    for (int a = 0; a < A.length; a++)
    {
      A[a] = (a + 1) * 2;
      System.out.print(A[a] + " ");
    }

    int[] B = {10, 20, 30, 40, 50};

    System.out.println("");
    String[] D = new String[3];
    D[0] = "Dog";
    D[2] = "Cat";
    for (String animal : D)
    {
      System.out.print(animal + " ");
    }

		System.out.println(" ");
    Double[] C = new Double[4];
		C[0] = 5.6;
		C[1] = 9.9;
		for (Double num : C)
		{
			System.out.print(num + " ");
		}

		System.out.println("");
		Scanner sc = new Scanner(System.in);
		String[] E = new String[10];
		System.out.println("Enter 10 words");
		for (int e = 0; e < E.length; e++)
		{
			E[e] = sc.nextLine();
		}
		for (String word : E)
		{
			System.out.print(word + " ");
		}

		System.out.println("");
		int[] F = new int[20];
		System.out.println("Enter 20 numbers");
		for (int f = 0; f < F.length; f++)
		{
			F[f] = sc.nextInt();
		}
		for (int num : F)
		{
			System.out.print(num + " ");
		}
  }
}