import java.util.Scanner;

class Main
{
  public static void main(String[] args)
  {
    Scanner sc = new Scanner(System.in);
    while (true)
    {
      System.out.println("Ask a yes or no question?");
      String question = sc.nextLine();
      int answerNum = (int)(Math.random() * 4 + 1);
      switch (answerNum)
      {
        case 1:
          System.out.println("Without a doubt.");
          break;
        case 2:
          System.out.println("Yes.");
          break;
        case 3:
          System.out.println("Ask again later.");
          break;
        case 4:
          System.out.println("No.");
          break;
        case 5:
          System.out.println("XXXXXXX thinks so.");
          break;
      }
    }
  }
}