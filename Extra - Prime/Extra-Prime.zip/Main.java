import java.util.Scanner;

class Main
{
  public static void main(String[] args)
  {
    Scanner sc = new Scanner(System.in);
    boolean primeNum = false;
    System.out.println("Enter a number: ");
    int num = sc.nextInt();

    for (int checkedNum = 1; checkedNum < num; checkedNum++)
    {
      for (int i = 2; i < checkedNum; i++)
      {
        if (checkedNum % i == 0)
        {
          primeNum = false;
          break;
        }
        else
        {
          primeNum = true;
        }
      }
      if(primeNum)
      {
        System.out.println(checkedNum);
      }
    }
  }
}