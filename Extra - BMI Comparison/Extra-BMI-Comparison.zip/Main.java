class Main
{
  public static void main(String[] args)
	{
    String[] name = {"Donald", "Bernie", "Hillary", "Alexandra", "Joe"};
		double[] height = {1.90, 1.83, 1.67, 1.68, 183};
		double[] weight = {110, 80, 60, 65, 68};

		int maxIndex = CalculateBMI(name, height, weight);

		System.out.println("The person with the highest BMI is: " + name[maxIndex]);
  }

	private static int CalculateBMI(String[] name, double[] height, double[] weight)
	{
		double bmi[] = new double[5];
		double maxBMI = 0;
		int maxIndex = 0;
		for (int index = 0; index < 5; index++)
		{
			bmi[index] = weight[index] / (height[index] * height[index]);
			if (bmi[index] > maxBMI)
			{
				maxBMI = bmi[index];
				maxIndex = index;
			}
		}
		return maxIndex;
	}
}