import java.util.Scanner;

class Main
{
  public static void main(String[] args)
	{
		int[] points = GetPoints();
		PrintResults(points, CalculateSlope(points));
  }

	private static int[] GetPoints()
	{
		int[] points = new int[4];

		Scanner sc = new Scanner(System.in);
		System.out.println("x1 -> ");
		points[0] = sc.nextInt();
		System.out.println("x2 -> ");
		points[1] = sc.nextInt();
		System.out.println("y1 -> ");
		points[2] = sc.nextInt();
		System.out.println("y2 -> ");
		points[3] = sc.nextInt();

		return points;
	}

	private static double CalculateSlope(int[] points)
	{
		double slope;
		slope = (points[3] - points[2]) / (points[1] - points[0]);
		return slope;
	}

	private static void PrintResults(int[] points, double slope)
	{
		System.out.println("Slope of points (" + points[0] + ", " + points[2] + ") and (" +  + points[1] + ", " + points[3] + ") is " + slope);
	}
}