class Main
{
  public static void main(String[] args)
  {
    //5
    System.out.println("Divided by 2:");
    for (int a = 1; a <= 100; a++)
    {
      if (a % 2 == 0)
      {
        System.out.print(a + " ");
      }
    }

    System.out.println("\nDivided by 7:");
    for (int b = 1; b <= 100; b++)
    {
      if (b % 7 == 0)
      {
        System.out.print(b + " ");
      }
    }
    System.out.println("\nDivided by 2 & 7:");
    for (int c = 1; c <= 100; c++)
    {
      if (c % 2 == 0 && c % 7 == 0)
      {
        System.out.print(c + " ");
      }
    }
  }
}