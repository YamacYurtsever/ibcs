import java.util.Scanner;

class Main
{
  public static void main(String[] args)
  {
    for (int a = 0; a <= 25; a++)
    {
      System.out.print(a + " ");
    }

    System.out.println("\n");

    for (int b = 10; b > 0; b--)
    {
      System.out.print(b + " ");
    }

    System.out.println("\n"); 

    for (int c = 1; c <= 40; c += 2)
    {
      System.out.print(c + " ");
    }

    System.out.println("\n"); 

    for (int d = 0; d <= 40; d += 2)
    {
      System.out.print(d + " ");
    }

    System.out.println("\n");

    for (int e = 0; e <= 200; e += 10)
    {
      System.out.print(e + " ");
    }

    System.out.println("\n"); 

    for (int f = -10; f >= -20; f--)
    {
      System.out.print(f + " ");
    }

    System.out.println("\n");   

    for (int g = 1; g <= 10; g++)
    {
      System.out.println("computer");
    }

    System.out.println("");   

    Scanner sc = new Scanner(System.in);
    System.out.println("how many times would you like to see the same sentence?");
    int x = sc.nextInt();

    for (int h = 0; h < x; h++)
    {
      System.out.println("This will be printed " + x + " times to the screen");
    }
  }
}