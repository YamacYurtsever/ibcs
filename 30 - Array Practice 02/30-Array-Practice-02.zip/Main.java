class Main
{
  public static void main(String[] args)
	{
		//1
    int[] A = {10, 20, 30, 40, 50};
		int addedValues = 0;
		for (int a : A)
		{
			addedValues += a;
		}
		int average = addedValues /= A.length;
		System.out.println(average + "\n");

		//2
		int[] B = new int[A.length];
		for (int b = 0; b < B.length; b++)
		{
			B[b] = A[b];
		}
		for (int b : B)
		{
			System.out.print(b + " ");
		}
		System.out.println("\n");

		//3
		int number = 20;
		boolean contains = false;
		for (int b : B)
		{
			if (b == number)
			{
				contains = true;
				break;
			}
		}
		if (contains)
			System.out.println("B contains " + number + "\n");
		else
			System.out.println("B doens't contain " + number + "\n");

		//4
		for (int b = B.length - 1; b >= 0; b--)
		{
			System.out.print(B[b] + " ");
		}
		System.out.println("\n");

		//5
		int length;
		if (A.length >= B.length)
			length = A.length;
		else
			length = B.length;
		boolean same = true;
		for (int a = 0; a < length; a++)
		{
			if (A[a] != B[a])
			{
				same = false;
				break;
			}
		}
		if (same)
		 System.out.println("A and B are the same" + "\n");
		else if (same)
		 System.out.println("A and B aren't the same" + "\n");

		//6
		int numCount = 100;
		int maxNum = 50;
		int[] C = new int[numCount];
		for (int c = 0; c < C.length; c++)
		{
			C[c] = (int)(Math.random() * maxNum);
		}
		for (int c : C)
		{
			System.out.print(c + " ");
		}
		System.out.println("\n");

		//7
		int[] D = new int[A.length - 1];
		int a = 0;
		int d = 0;
		int index = 2;
		while (a < A.length)
		{
			if (A[a] == A[index])
			{
				a++;
				continue;
			}

			D[d] = A[a];
			a++;
			d++;
		}
		for (int num : D)
		{
			System.out.print(num + " ");
		}
		System.out.println("\n");


		//8
		int highest = C[0];
		int secondHighest = C[1];
		for (int c = 0; c < C.length; c++)
		{
			if (C[c] >= highest)
			{
				secondHighest = highest;
				highest = C[c];
			}
			else if (C[c] >= secondHighest)
			{
				secondHighest = C[c];
			}
		}
		System.out.println(secondHighest + "\n");

		//8.5
		System.out.println(highest + "\n");

		//9
		String[] E = {"Apple", "Pear"};
		String[] F = {"Strawberry", "Cherry", "Watermelon", "Grape"};
		String[] G = new String[E.length + F.length];
		for (int g = 0; g < G.length; g++)
		{
			if (g < E.length)
			{
				G[g] = E[g];
			}
			else
			{
				G[g] = F[g - E.length];
			}
		}
		for (String g : G)
		{
			System.out.print(g + " ");
		}
		System.out.println("\n");

		//10
		String[] H = new String[G.length];
		for (int g = 0; g < G.length; g++)
		{
			H[g] = G[G.length - (g + 1)];
		}
		for (String h : H)
		{
			System.out.print(h + " ");
		}
		System.out.println("\n");

		//11
		int x;
		if (E.length <= G.length)
			x = E.length;
		else
			x = G.length;
		String[] X = new String[x];
		int y = 0;
		int z = 0;
		while (y < x)
		{
			if (G[y].equals(E[y]))
			{
				X[z] = G[y];
				z++;
			}
			y++;
		}
		for (String word : X)
		{
			if (word != null)
				System.out.print(word + " ");
		}
		System.out.println("\n");

		//12
		int[] I = new int[C.length];
		int i = 0;
		int c = 0;
		while (c < C.length)
		{
			if (C[c] != 0)
			{
				I[i] = C[c];
				i++;
			}
			c++;
		}
		for (int num : I)
		{
			System.out.print(num + " ");
		}
	}
}