import java.util.Scanner;

class Main
{
  public static void main(String[] args)
	{
    int[][] array = new int[3][3];

		//input numbers
		Scanner sc = new Scanner(System.in);
		for (int row = 0; row < array.length; row++)
		{
			System.out.println("\nRow " + (row+1) + "\nEnter " + array[row].length + " numbers:");
			for (int column = 0; column < array[row].length; column++)
			{
				array[row][column] = sc.nextInt();
			}
		}
		System.out.println("");

		//find average
		int average = 0; 
		int elementNum = 0;
		for (int[] arr : array)
		{
			for (int num : arr)
			{
				average += num;
				elementNum++;
			}
		}
		average /= elementNum;
		System.out.println("Average: " + average);
		System.out.println("");

		//find the max in each row
		for (int x = 0; x < array.length; x++)
		{
			int max = array[x][0];
			for (int y = 1; y < array[x].length; y++)
			{
				if (array[x][y] > max)
				{
					max = array[x][y];
				}
			}
			System.out.println("Max in Row " + x + ": " + max);
		}
  }
}