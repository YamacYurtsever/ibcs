import java.util.Scanner;

class Main
{
  public static void main(String[] args)
  {
    Scanner input = new Scanner(System.in);

    //value variables
    int quarters;
    int dimes;
    int nickels;
    int pennies;
    int totalCents;
    int dollars;
    int cents;

    //exchange variables
    int choice;
    String currencyType;
    double EurExchange = 0.81190;
    double GbpExchange = 0.73635;
    double TlExchange = 7.28091;
    double CadExchange = 1.26794;
    double SarExchange = 3.75000;
    double convertedValue;

    //input the values
    System.out.println("How many quarters do you have: ");
    quarters = input.nextInt();
    System.out.println("How many dimes do you have: ");
    dimes = input.nextInt();
    System.out.println("How many nickels do you have: ");
    nickels = input.nextInt();
    System.out.println("How many pennies do you have: ");
    pennies = input.nextInt();

    //calculate the total value
    totalCents = (quarters * 25) + (dimes * 10) + (nickels * 5) + pennies;
    dollars = totalCents / 100;
    cents = totalCents % 100;
    System.out.println("Total value: " + dollars + "dollars " + cents + "cents");

    //input exchange type
    System.out.println("Enter the number on the left of the requested currency");
    System.out.println("1: USD\n2: EUR\n3: GBP\n4: TL\n5: CAD\n6: SAR");
    choice = input.nextInt();

    //exchange the money
    convertedValue = ((double)totalCents / 100);
    switch(choice)
    {
      case 1:
        currencyType = "US Dollars";
        break;

      case 2:
        currencyType = "Euros";
        convertedValue *= EurExchange;
        break;

      case 3:
        currencyType = "GB Pounds";
        convertedValue *= GbpExchange;
        break;

      case 4:
        currencyType = "Turkish Liras";
        convertedValue *= TlExchange;
        break;

      case 5:
        currencyType = "Canadian Dollars";
        convertedValue *= CadExchange;
        break;

      case 6:
        currencyType = "Saudi Arabia Riyal";
        convertedValue *= SarExchange;
        break;

      default:
        currencyType = "US Dollars";
        break;
    }
    System.out.println("Amount of " + currencyType + ": " + convertedValue);
  }
}