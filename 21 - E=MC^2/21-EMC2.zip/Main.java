import java.util.Scanner;

class Main
{
  public static void main(String[] args)
  {
    Scanner sc = new Scanner(System.in);
    double speedOfLight = 299792458;

    while(true)
    {
      System.out.println("Enter kilos of mass: ");
      double mass = sc.nextDouble();
      System.out.println("e = m * C^2...");
      System.out.println("m = " + mass + " kg");
      System.out.println("C = " + speedOfLight + " m/s");
      double e = mass * (speedOfLight * speedOfLight);
      System.out.println(e + " joules of energy!");
      System.out.println("");
    }
  }
}