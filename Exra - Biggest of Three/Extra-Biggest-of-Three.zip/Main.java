import java.util.Scanner;

class Main
{
  public static void main(String[] args)
	{
		System.out.println("Biggest of these three numbers is: " + CalculateMax(GetNumbers()));
  }

	static int[] GetNumbers()
	{
		int[] numbers = new int[3];

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter three numbers");
		numbers[0] = sc.nextInt();
		numbers[1] = sc.nextInt();
		numbers[2] = sc.nextInt();

		return numbers;
	}

	static int CalculateMax(int[] numbers)
	{
		int biggest = numbers[0];

		for (int i = 1; i < numbers.length; i++)
		{
			if (numbers[i] > biggest)
				biggest = numbers[i];
		}		

		return biggest;
	}
}