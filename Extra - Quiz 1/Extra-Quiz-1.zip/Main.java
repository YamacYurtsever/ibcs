import java.util.Scanner;

class Main
{
  public static void main(String[] args)
	{
		int[] Product_Id = {5, 10, 15, 20, 25};
		int[] Unit_Price = {10, 20, 30, 40, 50};

		//find average
    int averagePrice = 0;
    for (int price : Unit_Price)
    {
      averagePrice += price;
    }
    averagePrice /= Unit_Price.length;
		System.out.println("Average Price: " + averagePrice + "\n");
		
		//find unit price from product id
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Product Id: ");
		int id = sc.nextInt();
		int index = 0;
		boolean exists = false;
		for (int num : Product_Id)
		{
			if (num == id)
			{
				exists = true;
				break;
			}
		}
		if(exists)
		{
			while (index < Product_Id.length)
			{
				if (Product_Id[index] == id)
				{
					break;
				}
				index++;
			}
			System.out.println("Unit Price: " + Unit_Price[index]);
		}
		else
		{
			System.out.println("The ID you have entered doesn't exist");
		}
  }
}