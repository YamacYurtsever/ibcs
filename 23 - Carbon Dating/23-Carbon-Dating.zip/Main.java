import java.util.Scanner;

class Main
{
  public static void main(String[] args)
  {
    //Lookup Table
    double percent = 100;
    int years = 0;
    System.out.println("Carbon dating lookup table");
    System.out.println("percent C-14 remaining: years passed");
    for(int i = 0; i < 20; i++)
    {
      System.out.println(percent + "%:   " + years + "years");
      percent /= 2;
      years += 5700;
    }

    System.out.println("");

    while (true)
    {
      //With Input
      Scanner sc = new Scanner(System.in);
      System.out.println("What percent of natural carbon-14 does your sample have?");
      double carbonPercentage = sc.nextDouble();
      System.out.println(carbonPercentage + "%" + " carbon-14...");
      double age = ((Math.log(carbonPercentage / 100)) / -0.693)  * 5700;
      System.out.println("It is: " + age + " years old");
    }
  }
}