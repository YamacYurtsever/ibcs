//AUTOMATED
import java.util.Scanner;

class Main
{
  public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the length of the sides of your tornado");
		int sideLength = sc.nextInt();

    int number = 1;
		int[][] tornado = new int[sideLength][sideLength];
		int columnIndex;
		int rowIndex;

		for (int turn = 0; turn < (sideLength / 2); turn++)
		{
			int beginning = 0 + turn;
			int end = (sideLength - 1) - turn;

			//RIGHT
			columnIndex = 0 + turn;
			int maxColumn = sideLength - turn;
			while (columnIndex < maxColumn)
			{
				tornado[beginning][columnIndex] = number;
				columnIndex++;
				number++;
			}

			//DOWN
			rowIndex = 1 + turn; 
			int maxRow = sideLength - turn;
			while (rowIndex < maxRow)
			{
				tornado[rowIndex][end] = number;
				rowIndex++;
				number++;
			}

			//LEFT
			columnIndex = (sideLength - 2) - turn;
			int minColumn = -1 + turn;
			while (columnIndex > minColumn)
			{
				tornado[end][columnIndex] = number;
				columnIndex--;
				number++;
			}

			//UP
			rowIndex = (sideLength - 2) - turn;
			int minRow = 0 + turn;
			while (rowIndex > minRow)
			{
				tornado[rowIndex][beginning] = number;
				rowIndex--;
				number++;
			}
		}

		//MIDDLE
		if (tornado[tornado.length/2][tornado.length/2] == 0)
		{
			tornado[tornado.length/2][tornado.length/2] = number++;
		}


		//PRINT
		for (int row[] : tornado)
		{
			for (int numbers : row)
			{
				if (Integer.toString(numbers).length() < Integer.toString(number).toString().length())
				{
					for (int digit = 0; digit < (Integer.toString(number).length() - Integer.toString(numbers).toString().length()); digit++)
					{
						System.out.print(0);
					}
				}
				System.out.print(numbers + " ");
			}
			System.out.println();
		}
  }
}

//QUESTION
/*
class Main
{
  public static void main(String[] args)
	{
    int number = 1;
		int[][] tornado = new int[5][5];

		//RIGHT 1
		int a = 0;
		while (a < 5)
		{
			tornado[0][a] = number;
			a++;
			number++;
		}

		//DOWN 1
		int b = 1; 
		while (b < 5)
		{
			tornado[b][4] = number;
			b++;
			number++;
		}

		//LEFT 1
		int c = 3;
		while (c > -1)
		{
			tornado[4][c] = number;
			c--;
			number++;
		}

		//UP 1
		int d = 3;
		while (d > 0)
		{
			tornado[d][0] = number;
			d--;
			number++;
		}

		//RIGHT 2
		int e = 1;
		while (e < 4)
		{
			tornado[1][e] = number;
			e++;
			number++;
		}

		//DOWN 2
		int f = 2; 
		while (f < 4)
		{
			tornado[f][3] = number;
			f++;
			number++;
		}

		//LEFT 2
		int g = 2;
		while (g > 0)
		{
			tornado[3][g] = number;
			g--;
			number++;
		}

		//UP 2
		int h = 2;
		while (h > 1)
		{
			tornado[h][1] = number;
			h--;
			number++;
		}

		//MIDDLE
		tornado[tornado.length/2][tornado.length/2] = number++;


		//PRINT
		for (int row[] : tornado)
		{
			for (int numbers : row)
			{
				System.out.print(numbers);
			}
			System.out.println();
		}
	}
}
*/