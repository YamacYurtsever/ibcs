import java.util.Scanner;

class Main
{
  public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the length of the sides of your tornado");
		int sideLength = sc.nextInt();

    int number = 1;
		int[][] tornado = new int[sideLength][sideLength];
		int columnIndex;
		int rowIndex;

		for (int turn = 0; turn < (sideLength / 2); turn++)
		{
			int beginning = 0 + turn;
			int end = (sideLength - 1) - turn;

			//RIGHT
			columnIndex = 0 + turn;
			int maxColumn = sideLength - turn;
			while (columnIndex < maxColumn)
			{
				tornado[beginning][columnIndex] = number;
				columnIndex++;
				number++;
			}

			//DOWN
			rowIndex = 1 + turn; 
			int maxRow = sideLength - turn;
			while (rowIndex < maxRow)
			{
				tornado[rowIndex][end] = number;
				rowIndex++;
				number++;
			}

			//LEFT
			columnIndex = (sideLength - 2) - turn;
			int minColumn = -1 + turn;
			while (columnIndex > minColumn)
			{
				tornado[end][columnIndex] = number;
				columnIndex--;
				number++;
			}

			//UP
			rowIndex = (sideLength - 2) - turn;
			int minRow = 0 + turn;
			while (rowIndex > minRow)
			{
				tornado[rowIndex][beginning] = number;
				rowIndex--;
				number++;
			}
		}

		//MIDDLE
		if (tornado[tornado.length/2][tornado.length/2] == 0)
		{
			tornado[tornado.length/2][tornado.length/2] = number++;
		}


		//PRINT
		for (int row[] : tornado)
		{
			for (int numbers : row)
			{
				if (Integer.toString(numbers).length() < Integer.toString(number).toString().length())
				{
					for (int digit = 0; digit < (Integer.toString(number).length() - Integer.toString(numbers).toString().length()); digit++)
					{
						System.out.print(0);
					}
				}
				System.out.print(numbers + " ");
			}
			System.out.println();
		}
  }
}