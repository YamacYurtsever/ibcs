class Main
{
  public static void main(String[] args) 
	{
		//1
    int[][] array1 = {{1, 2, 3}, {11, 12, 13, 14, 15}, {1}};
		array1[1][3] = 99;
		for (int i = 0; i < array1[1].length; i++)
		{
			System.out.println(array1[1][i]);
		}
		System.out.println("");

		//2
		int[][] array2 = {{1}, {11, 12, 13, 14, 15}, {96, 88}};
		for (int i = 0; i < array2.length; i++)
		{
			for (int j = 0; j < array2[i].length; j++)
			{
				System.out.print(array2[i][j] + " ");
			}
			System.out.println("");
		}
  }
}