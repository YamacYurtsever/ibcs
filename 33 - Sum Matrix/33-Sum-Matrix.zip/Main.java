import java.util.Scanner;

class Main
{
  public static void main(String[] args)
	{
		//create the array
		Scanner sc = new Scanner(System.in);
    System.out.println("Enter the number of rows --> ");
		int rowNum = sc.nextInt();
		System.out.println("Enter the number of columns --> ");
		int columnNum = sc.nextInt();
		System.out.println("");

		int[][] array = new int[rowNum][columnNum];
		for (int x = 0; x < array.length; x++)
		{
			for (int y = 0; y < array[x].length; y++)
			{
				array[x][y] = (int)(Math.random() * 9 + 1);
			}
		}

		//print array and sum of rows
		int rowSum = 0;
		for (int[] arr : array)
		{
			for (int num : arr)
			{
				rowSum += num;
				System.out.print(num + "  ");
			}
			System.out.println("  " + rowSum);
			rowSum = 0;
		}
		System.out.println("");

		//print sum of columns
		int columnSum = 0;
		for (int b = 0; b < columnNum; b++)
		{
			for (int a = 0; a < rowNum; a++)
			{
				columnSum += array[a][b];
			}
			System.out.print(columnSum + " ");
			columnSum = 0;
		}
  }
}