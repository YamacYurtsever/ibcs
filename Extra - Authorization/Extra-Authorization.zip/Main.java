import java.util.Scanner;

class Main
{
  public static void main(String[] args)
  {
    Scanner sc = new Scanner(System.in);

    System.out.println("Set your username: ");
    String setUsername = sc.nextLine();
    System.out.println("Set your password: ");
    String setPassword = sc.nextLine();

    String triedUsername = "";
    String triedPassword = "";
    System.out.println("");
    while (!triedUsername.equals(setUsername) || !triedPassword.equals(setPassword))
    {
      System.out.println("Enter your username: ");
      triedUsername = sc.nextLine();
      System.out.println("Enter your password: ");
      triedPassword = sc.nextLine();
      System.out.println("");
    }
    System.out.println("Welcome");
  }
}