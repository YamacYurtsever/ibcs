import java.util.Scanner;

class Main
{
  public static void main(String[] args)
  {
    String damage;
    Scanner input = new Scanner(System.in);

    System.out.println("Enter a magnitude on the Richter scale ==>> ");
    double scale = input.nextDouble();

    if (scale >= 0)
    {
      if (scale > 8.0)
        damage = "Most structures fall";

      else if (scale > 7.0)
        damage = "Most buildings destroyed";

      else if (scale > 6.0)
        damage = "Many buildings considerably damaged; some collapse";

      else if (scale > 4.5)
        damage = "Damage to poorly constructed buildings";

      else if (scale > 3.5)
        damage = "Felt by many people, no destruction";

      else
        damage = "Generally not felt by people";

      System.out.println("\nDamage = " + damage);
    }

    else
      System.out.println("\nThis number is not valid.");
  }
}